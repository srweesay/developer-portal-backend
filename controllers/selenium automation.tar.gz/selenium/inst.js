const { Builder, By, Key, until } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");

const username = "nbet15";
const password = "m";

const args = process.argv.slice(2);

const org = {
  fullNameEnglish: args[0],
  idType: args[1],
  swiftBic: args[2],
  proprietaryId: args[3],
  shortName: args[4],
  fullNameAmharic: args[5],
  legacyCode: args[6],
  mainPhoneNumber: args[7],
  mainEmail: args[8],
  contactPersons: [
    {
      fullName: args[9],
      department: args[10],
      position: args[11],
      phoneNumber: args[12],
      email: args[13],
    },
  ],
};

async function initializeDriver() {
  const chromeOptions = new chrome.Options()
    .excludeSwitches("enable-automation")
    .addArguments("--headless"); // Run in headless mode
  return new Builder()
    .forBrowser("chrome")
    .setChromeOptions(chromeOptions)
    .build();
}

async function login(driver, username, password) {
  try {
    await driver.get("https://10.20.220.36:9443/csd");
    await driver.manage().window().maximize();
    await driver.wait(until.elementLocated(By.id("details-button"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("proceed-link"))).click();
    await driver.sleep(1000);
    await driver
      .wait(until.elementLocated(By.name("j_username")))
      .sendKeys(username);
    await driver.wait(until.elementLocated(By.id("pass"))).sendKeys(password);
    await driver.wait(until.elementLocated(By.id("btnLogin"))).click();
  } catch (error) {
    console.error("Login failed:", error);
  }
}

async function createInstitution(params) {
  const driver = await initializeDriver();
  try {
    await login(driver, username, password);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            "/html/body/div/core-menu/div/div[1]/div[3]/div[4]/div[2]/div[1]"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.sleep(3000);
    await driver.switchTo().frame("ContentFrame");
    await driver
      .wait(until.elementLocated(By.id("name")))
      .sendKeys(params.fullNameEnglish);
    await driver.sleep(2000);

    const idtype = await driver.wait(
      until.elementLocated(
        By.xpath(
          '//*[@id="entryForm"]/div[2]/div[1]/div[2]/div[2]/div/span/input'
        )
      )
    );
    await idtype.sendKeys(`\b${params.idType}`);
    await driver
      .wait(until.elementLocated(By.xpath('//*[@id="ui-id-1"]')))
      .click();
    const SBIC = await driver.wait(
      until.elementLocated(By.id("identification"))
    );
    await SBIC.sendKeys(params.swiftBic + params.proprietaryId);
    const short = await driver.wait(until.elementLocated(By.id("shortName")));
    await short.sendKeys(params.shortName);

    const localName = await driver.wait(
      until.elementLocated(By.id("nameLocal"))
    );
    await localName.sendKeys(params.fullNameAmharic);

    const legacyCode = await driver.wait(until.elementLocated(By.id("lei")));
    await legacyCode.sendKeys(params.legacyCode);
    await driver.wait(until.elementLocated(By.css("#ContactId > a"))).click();
    await driver
      .wait(until.elementLocated(By.id("phoneNo")))
      .sendKeys(params.mainPhoneNumber);
    await driver
      .wait(until.elementLocated(By.id("emailAddress")))
      .sendKeys(params.mainEmail);

    await driver.wait(until.elementLocated(By.id("btnValidate"))).click();
    await driver.sleep(4000);
    await driver
      .wait(until.elementLocated(By.className("icon-circle-check")))
      .click();
    approveInstitution(driver, params);
  } catch (error) {
    console.error("Error creating user participant:", error);
  } finally {
    //   await driver.quit();
  }
}

async function approveInstitution(driver, params) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");
    await driver
      .wait(until.elementLocated(By.id("swiftId")))
      .sendKeys(params.swiftBic + params.proprietaryId);
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.css("#ui-id-1"))).click();
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.sleep(3000);
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving participant:", error);
  }
}

createInstitution(org);
