const { createAndApproveUser } = require("./new");

const args = process.argv.slice(2);

const user = args[0] || "";
const fullName = args[1] || "";
const swift = args[2] || "";
const pass = args[3] || "";

(async () => {
  try {
    await createAndApproveUser({
      user,
      fullName,
      swift,
      pass,
    });
  } catch (error) {
    console.log(error);
    throw new Error({ message: "Automation Script Failed To Create User" });
  }
})();
