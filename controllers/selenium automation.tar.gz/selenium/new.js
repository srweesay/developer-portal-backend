const { Builder, By, Key, until } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");

async function initializeDriver() {
  const chromeOptions = new chrome.Options()
    .excludeSwitches("enable-automation")
    .addArguments("--headless") // Run in headless mode
    .addArguments("--no-sandbox") // Recommended for running as root
    .addArguments("--disable-dev-shm-usage") // Handle memory issues in Docker
    .addArguments("--ignore-certificate-errors") // Ignore SSL certificate errors
    .addArguments("--allow-insecure-localhost") // Allow insecure localhost
    .addArguments("--disable-web-security") // Disables web security (may help with some SSL issues)
    .addArguments("--reduce-security-for-testing");

  return new Builder()
    .forBrowser("chrome")
    .setChromeOptions(chromeOptions)
    .build();
}

async function login(driver, username, password) {
  try {
    await driver.get("https://10.20.220.36:9443/csd");
    await driver.manage().window().maximize();
    await driver
      .wait(until.elementLocated(By.name("j_username")))
      .sendKeys(username);
    await driver.wait(until.elementLocated(By.id("pass"))).sendKeys(password);
    await driver.wait(until.elementLocated(By.id("btnLogin"))).click();
  } catch (error) {
    console.error("Login failed:", error);
  }
}

async function createUserParticipant(params) {
  const driver = await initializeDriver();
  try {
    await login(driver, "nbet15", "m");

    const {
      instName,
      institution,
      participantName,
      participantSBIC,
      participantShortName,
      economicType,
      taxId,
    } = params;

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div.children-container > div:nth-child(2) > div > div"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.switchTo().frame("ContentFrame");

    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > span > input"
        )
      )
      .sendKeys(`\b${institution}`);
    await driver
      .wait(until.elementLocated(By.xpath("//li[@class='ui-menu-item']")))
      .click();
    await driver.sleep(2000);

    const name = await driver.wait(until.elementLocated(By.id("name")));
    await name.clear();
    await name.sendKeys(participantName);

    const SBIC = await driver.wait(
      until.elementLocated(By.id("identification"))
    );
    await SBIC.clear();
    await SBIC.sendKeys(participantSBIC);

    const short = await driver.wait(until.elementLocated(By.id("shortName")));
    await short.clear();
    await short.sendKeys(participantShortName);

    await driver.findElement(By.id("BehavioralId")).click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(2) > div:nth-child(2) > div > span > input"
          )
        )
      )
      .click();
    await driver
      .wait(until.elementLocated(By.css("#ui-id-3 > li:nth-child(6)")))
      .click();

    await driver.sleep(2000);
    await driver.wait(until.elementLocated(By.id("taxId"))).sendKeys(taxId);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(3) > div:nth-child(2) > div > span > input"
          )
        )
      )
      .click();
    await driver
      .wait(until.elementLocated(By.css("#ui-id-6 > li:nth-child(2)")))
      .click();

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(2) > div:nth-child(3) > div > span > input"
          )
        )
      )
      .sendKeys(`\b${economicType}`);
    await driver
      .wait(until.elementLocated(By.xpath("//li[normalize-space()='Banking']")))
      .click();

    await driver.sleep(3000);
    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(4) > div.row > div:nth-child(2) > div > div > label.toggle"
        )
      )
      .click();

    await driver.wait(until.elementLocated(By.id("btnValidate"))).click();
    await driver.sleep(4000);
    await driver
      .wait(until.elementLocated(By.className("icon-circle-check")))
      .click();

    await ApproveParticipant(driver, participantSBIC);
  } catch (error) {
    console.error("Error creating user participant:", error);
  } finally {
    await driver.quit();
  }
}

async function ApproveParticipant(driver, swift) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");
    await driver.wait(until.elementLocated(By.id("swiftId"))).sendKeys(swift);
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving participant:", error);
  }
}

async function createAndApproveUser({ user, fullName, swift, pass }) {
  const driver = await initializeDriver();
  try {
    await login(driver, "nbet15", "m");

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(2) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//div[contains(text(),'Users')]"))
      .click();
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.switchTo().frame("ContentFrame");

    await driver
      .wait(
        until.elementLocated(
          By.css("#groupSelect > div > input.select-box.select-field")
        )
      )
      .sendKeys(swift);
    await driver
      .wait(until.elementLocated(By.css("#groupSelect > div > div > div")))
      .click();
    await driver.findElement(By.id("btnOk")).click();

    await driver.wait(until.elementLocated(By.id("username"))).sendKeys(user);
    await driver
      .wait(until.elementLocated(By.id("fullName")))
      .sendKeys(fullName);
    await driver.findElement(By.id("password")).sendKeys(pass);
    await driver.findElement(By.id("verifyPassword")).sendKeys(pass);

    const profile = await driver.wait(
      until.elementLocated(
        By.css(
          "#entryForm > div.form-content > div.row > div:nth-child(3) > div > c-select > div"
        )
      )
    );
    await driver.executeScript("arguments[0].scrollIntoView(true);", profile);
    const actions = driver.actions();
    await actions.move({ origin: profile }).click().perform();
    await driver
      .wait(until.elementLocated(By.xpath("//div[normalize-space()='GROUP']")))
      .click();

    await driver.findElement(By.id("btnValidate")).click();
    await driver.sleep(3000);
    await driver.findElement(By.id("btnOk")).click();

    await approve(driver, user);
  } catch (error) {
    console.error("Error creating and approving user:", error);
  } finally {
    await driver.quit();
  }
}

async function approve(driver, user) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");

    await driver
      .wait(until.elementLocated(By.id("userBusinessFilterUsername")))
      .sendKeys(user);
    await driver.sleep(2000);
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving user:", error);
  }
}

module.exports = { createUserParticipant, createAndApproveUser };
