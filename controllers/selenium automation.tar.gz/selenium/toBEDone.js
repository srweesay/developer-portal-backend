const {
  createInstitution,
  createParticipant,
  createIssuer,
  createRegulator,
  createSettelementBank,
} = require("./automation");

async function go() {
  try {
    const cre = await createIssuer({
      accountNO: "54645",
      cashAccount: "cbe",
      establishedDate: "12-25-2015",
      fullNameEnglish: "Addis International Bank S.c",
      legacyCode: "",
      proprietaryId: "",
      swiftBic: "ABSCETAA",
      type: "bank",
    });
  } catch (error) {
    console.log(error);
  }
}

go();
