const { Builder, By, Key, until } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");

async function initializeDriver() {
  const chromeOptions = new chrome.Options()
    .excludeSwitches("enable-automation")
    .addArguments("--headless"); // Run in headless mode

  return new Builder()
    .forBrowser("chrome")
    .setChromeOptions(chromeOptions)
    .build();
}

var username = "nbet15";
var pass = "m";

async function login(driver, username, password) {
  try {
    await driver.get("https://172.19.1.23:9443/csd");
    await driver.manage().window().maximize();
    await driver.wait(until.elementLocated(By.id("details-button"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("proceed-link"))).click();
    await driver.sleep(1000);
    await driver
      .wait(until.elementLocated(By.name("j_username")))
      .sendKeys(username);
    await driver.wait(until.elementLocated(By.id("pass"))).sendKeys(password);
    await driver.wait(until.elementLocated(By.id("btnLogin"))).click();
  } catch (error) {
    console.error("Login failed:", error);
  }
}

const args = process.argv.slice(2);

const org = {
  fullNameEnglish: args[0],
  swiftBic: args[1],
  proprietaryId: args[2],
  type: args[3],
  taxId: args[4],
  roles: args[5],
  cashAccount: args[6],
  accountNO: args[7],
  mainPhoneNumber: args[8],
  mainEmail: args[9],
  contactPersons: [
    {
      fullName: args[10],
      position: args[11],
      phoneNumber: args[12],
      email: args[13],
      department: args[14],
    },
  ],
};

async function createUserParticipant(params) {
  const driver = await initializeDriver();
  try {
    await login(driver, username, pass);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div.children-container > div:nth-child(2) > div > div"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.switchTo().frame("ContentFrame");
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > span > input"
          )
        )
      )
      .sendKeys(`\b${params.fullNameEnglish}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-1 > li"))).click();
    await driver.sleep(5000);
    await driver.findElement(By.id("BehavioralId")).click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(2) > div:nth-child(2) > div > span > input"
          )
        )
      )
      .sendKeys(`\b${params.type}`);
    await driver
      .wait(until.elementLocated(By.css("#ui-id-3 > li:nth-child(2)")))
      .click();

    await driver.sleep(2000);
    await driver
      .wait(until.elementLocated(By.id("taxId")))
      .sendKeys(params.taxId);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(2) > div:nth-child(3) > div > span > input"
          )
        )
      )
      .sendKeys(`\b${params.roles}`);
    await driver
      .wait(until.elementLocated(By.xpath("//li[normalize-space()='Banking']")))
      .click();

    await driver.sleep(3000);
    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(3) > div:nth-child(2) > div > span > input"
        )
      )
      .click();
    await driver
      .wait(until.elementLocated(By.css("#ui-id-6 > li.ui-menu-item")))
      .click();

    let toggleElement = await driver.findElement(
      By.xpath("//div[4]//div[2]//div[1]//div[1]//div[1]//label[2]//span[1]")
    );
    await driver.executeScript(
      "arguments[0].scrollIntoView(true);",
      toggleElement
    );
    await toggleElement.click();
    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(4) > div.row > div:nth-child(2) > div > div > label.toggle"
        )
      )
      .click();
    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(4) > div.row > div:nth-child(3) > div > div > label.toggle"
        )
      )
      .click();
    let toggle = await driver.findElement(
      By.css(
        "#entryForm > div.form-content > div:nth-child(6) > div.row > div:nth-child(1) > div > div > label.toggle"
      )
    );
    await driver.executeScript("arguments[0].scrollIntoView(true);", toggle);
    // Click on the toggle element
    await toggle.click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(7) > div.row > div:nth-child(1) > div > div > label.toggle"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(7) > div.row > div:nth-child(2) > div > div > label.toggle"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(7) > div.row > div:nth-child(3) > div > div > label.toggle"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(7) > div.row > div:nth-child(4) > div > div > label.toggle"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(7) > div.row > div:nth-child(5) > div > div > label.toggle"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(7) > div.row > div:nth-child(6) > div > div > label.toggle"
          )
        )
      )
      .click();

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(8) > c-widget > div.table-box > div.widget-box-header > div.widget-button-container > div > button"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css("#cashAccount > input.select-box.select-field")
        )
      )
      .sendKeys(`\b${params.cashAccount}`);
    //   await driver.wait(until.elementLocated(By.css("#cashAccount > div"))).click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(8) > c-widget > div.table-box > div.modal-backdrop > div > div > div.row > div:nth-child(6) > div > div > div > label > span"
          )
        )
      )
      .click();
    await driver.sleep(4000);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(8) > c-widget > div.table-box > div.modal-backdrop > div > div > div.modal-buttons > button.button-primary"
          )
        )
      )
      .click();

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(8) > c-widget > div.row-box > div.row > div > div > span > input"
          )
        )
      )
      .sendKeys(`\b${params.cae.paymentOption}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-8 > li"))).click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#smTableBox > table > tbody > tr:nth-child(2) > td:nth-child(2) > div > div > span > input"
          )
        )
      )
      .sendKeys(`\b${params.cashAccount}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-9 > li"))).click();

    await driver
      .wait(until.elementLocated(By.css("#cashAccountNumber")))
      .sendKeys(params.accountNO);
    await driver
      .wait(until.elementLocated(By.css("#ContactId > a")))
      .sendKeys(params.accountNO);

    await driver
      .wait(until.elementLocated(By.id("phoneNo")))
      .sendKeys(params.mainPhoneNumber);
    await driver
      .wait(until.elementLocated(By.id("email")))
      .sendKeys(params.mainEmail);

    var contactPerson = await driver.findElement(
      By.css(
        "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.widget-box-header > div.widget-button-container > div > button"
      )
    );
    await driver.executeScript(
      "arguments[0].scrollIntoView(true);",
      contactPerson
    );
    // Click on the contactPerson element
    await contactPerson.click();
    await driver
      .wait(until.elementLocated(By.xpath('//*[@id="fullName"]')))
      .sendKeys(params.contactPersons[0].fullName);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.modal-backdrop > div > div.modal-content > div.row > div:nth-child(3) > div > div > input"
          )
        )
      )
      .sendKeys(params.contactPersons[0].position);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.modal-backdrop > div > div.modal-content > div.row > div:nth-child(3) > div > div > input"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.modal-backdrop > div > div.modal-content > div.row > div:nth-child(3) > div > div > input"
          )
        )
      )
      .sendKeys(params.contactPersons[0].position);
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            '//*[@id="entryForm"]/div[2]/div[9]/c-widget/div/div[3]/div/div/div[2]/div[5]/div/div/input'
          )
        )
      )
      .sendKeys(params.contactPersons[0].phoneNumber);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.modal-backdrop > div > div > div.row > div:nth-child(4) > div > div > input"
          )
        )
      )
      .sendKeys(params.contactPersons[0].email);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.modal-backdrop > div > div > div.row > div:nth-child(2) > div > div > input"
          )
        )
      )
      .sendKeys(params.contactPersons[0].department);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(9) > c-widget > div > div.modal-backdrop > div > div > div.modal-buttons > button.button-primary"
          )
        )
      )
      .click();
    await driver.wait(until.elementLocated(By.id("btnValidate"))).click();
    await driver
      .wait(until.elementLocated(By.className("icon-circle-check")))
      .click();

    await ApproveParticipant(driver, params);
  } catch (error) {
    console.error("Error creating user participant:", error);
  } finally {
    //   await driver.quit();
    // }
  }
}

async function ApproveParticipant(driver, params) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");
    await driver
      .wait(until.elementLocated(By.id("swiftId")))
      .sendKeys(params.swiftBic + params.proprietaryId);
    await driver.sleep(1000);
    console.log(params.fullNameEnglish);
    console.log(params.swiftBic);
    console.log(params.swiftBic + params.proprietaryId);
    console.log(params.proprietaryId);
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving participant:", error);
  }
}

async function createAndApproveUser({ user, fullName, swift, pass }) {
  const driver = await initializeDriver();
  try {
    await login(driver, "nbet15", "m");

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(2) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//div[contains(text(),'Users')]"))
      .click();
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.switchTo().frame("ContentFrame");

    await driver
      .wait(
        until.elementLocated(
          By.css("#groupSelect > div > input.select-box.select-field")
        )
      )
      .sendKeys(params.swiftBic + params.proprietaryId);
    await driver
      .wait(until.elementLocated(By.css("#groupSelect > div > div > div")))
      .click();
    await driver.findElement(By.id("btnOk")).click();

    await driver.wait(until.elementLocated(By.id("username"))).sendKeys(user);
    await driver
      .wait(until.elementLocated(By.id("fullName")))
      .sendKeys(fullName);
    await driver.findElement(By.id("password")).sendKeys(pass);
    await driver.findElement(By.id("verifyPassword")).sendKeys(pass);

    const profile = await driver.wait(
      until.elementLocated(
        By.css(
          "#entryForm > div.form-content > div.row > div:nth-child(3) > div > c-select > div"
        )
      )
    );
    await driver.executeScript("arguments[0].scrollIntoView(true);", profile);
    const actions = driver.actions();
    await actions.move({ origin: profile }).click().perform();
    await driver
      .wait(until.elementLocated(By.xpath("//div[normalize-space()='GROUP']")))
      .click();

    await driver.findElement(By.id("btnValidate")).click();
    await driver.sleep(3000);
    await driver.findElement(By.id("btnOk")).click();

    await approve(driver, user);
  } catch (error) {
    console.error("Error creating and approving user:", error);
  } finally {
    await driver.quit();
  }
}

async function approve(driver, user) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");

    await driver
      .wait(until.elementLocated(By.id("userBusinessFilterUsername")))
      .sendKeys(user);
    await driver.sleep(2000);
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving user:", error);
  }
}

createUserParticipant(org);
module.exports = { createUserParticipant, createAndApproveUser };
