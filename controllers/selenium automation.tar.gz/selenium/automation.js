const { spawn } = require("child_process");
const path = require("path");

const createInstitution = async (
  {
    fullNameEnglish,
    idType,
    swiftBic,
    proprietaryId,
    shortName,
    fullNameAmharic,
    legacyCode,
    mainPhoneNumber,
    mainEmail,
    contactFullName,
    contactDepartment,
    contactPosition,
    contactPhoneNumber,
    contactEmail,
  },
  timeout = 3 * 60 * 1000
) => {
  return new Promise((resolve) => {
    const scriptPath = path.join(__dirname, "inst.js");

    const args = [
      fullNameEnglish,
      idType,
      swiftBic,
      proprietaryId,
      shortName,
      fullNameAmharic,
      legacyCode,
      mainPhoneNumber,
      mainEmail,
      contactFullName,
      contactDepartment,
      contactPosition,
      contactPhoneNumber,
      contactEmail,
    ];

    const child = spawn("node", [scriptPath, ...args]);

    child.stdout.on("data", (data) => {
      console.log(`Output: ${data}`);
    });

    child.stderr.on("data", (data) => {
      console.error(`Error: ${data}`);
    });

    child.on("close", (code) => {
      console.log(`Child process exited with code ${code}`);
      return resolve(code === 0);
    });

    setTimeout(() => {
      console.error("Script timed out");
      child.kill();
      resolve(false);
    }, timeout);
  });
};

const createIssuer = async (
  {
    fullNameEnglish,
    legacyCode,
    type,
    establishedDate,
    cashAccount,
    accountNO,
    swiftBic,
    proprietaryId,
  },
  timeout = 3 * 60 * 1000
) => {
  return new Promise((resolve) => {
    const scriptPath = path.join(__dirname, "issuer.js");

    const args = [
      fullNameEnglish,
      legacyCode,
      type,
      establishedDate,
      cashAccount,
      accountNO,
      swiftBic,
      proprietaryId,
    ];

    const child = spawn("node", [scriptPath, ...args]);

    child.stdout.on("data", (data) => {
      console.log(`Output: ${data}`);
    });

    child.stderr.on("data", (data) => {
      console.error(`Error: ${data}`);
    });

    child.on("close", (code) => {
      console.log(`Child process exited with code ${code}`);
      return resolve(code === 0);
    });

    setTimeout(() => {
      console.error("Script timed out");
      child.kill();
      resolve(false);
    }, timeout);
  });
};

const createRegulator = async (
  { fullNameEnglish, legacyCode, regulatorType, swiftBic, proprietaryId },
  timeout = 3 * 60 * 1000
) => {
  return new Promise((resolve) => {
    const scriptPath = path.join(__dirname, "regulator.js");

    const args = [
      fullNameEnglish,
      legacyCode,
      regulatorType,
      swiftBic,
      proprietaryId,
    ];

    const child = spawn("node", [scriptPath, ...args]);

    child.stdout.on("data", (data) => {
      console.log(`Output: ${data}`);
    });

    child.stderr.on("data", (data) => {
      console.error(`Error: ${data}`);
    });

    child.on("close", (code) => {
      console.log(`Child process exited with code ${code}`);
      return resolve(code === 0);
    });

    setTimeout(() => {
      console.error("Script timed out");
      child.kill();
      resolve(false);
    }, timeout);
  });
};

const createSettelementBank = async (
  { fullNameEnglish, legacyCode, type, swiftBic, proprietaryId },
  timeout = 3 * 60 * 1000
) => {
  return new Promise((resolve) => {
    const scriptPath = path.join(__dirname, "sett.js");

    const args = [fullNameEnglish, legacyCode, type, swiftBic, proprietaryId];

    const child = spawn("node", [scriptPath, ...args]);

    child.stdout.on("data", (data) => {
      console.log(`Output: ${data}`);
    });

    child.stderr.on("data", (data) => {
      console.error(`Error: ${data}`);
    });

    child.on("close", (code) => {
      console.log(`Child process exited with code ${code}`);
      return resolve(code === 0);
    });

    setTimeout(() => {
      console.error("Script timed out");
      child.kill();
      resolve(false);
    }, timeout);
  });
};

const createParticipant = async (
  {
    fullNameEnglish,
    swiftBic,
    proprietaryId,
    type,
    taxId,
    roles,
    cashAccount,
    accountNO,
    mainPhoneNumber,
    mainEmail,
    contactFullName,
    contactPosition,
    contactPhoneNumber,
    contactEmail,
    contactDepartment,
  },
  timeout = 3 * 60 * 1000
) => {
  return new Promise((resolve) => {
    const scriptPath = path.join(
      __dirname,

      "participantAndUserCreate.js"
    );

    const args = [
      fullNameEnglish,
      swiftBic,
      proprietaryId,
      type,
      taxId,
      roles,
      cashAccount,
      accountNO,
      mainPhoneNumber,
      mainEmail,
      contactFullName,
      contactPosition,
      contactPhoneNumber,
      contactEmail,
      contactDepartment,
    ];

    const child = spawn("node", [scriptPath, ...args]);

    child.stdout.on("data", (data) => {
      console.log(`Output: ${data}`);
    });

    child.stderr.on("data", (data) => {
      console.error(`Error: ${data}`);
    });

    child.on("close", (code) => {
      console.log(`Child process exited with code ${code}`);
      return resolve(code === 0);
    });

    setTimeout(() => {
      console.error("Script timed out");
      child.kill();
      resolve(false);
    }, timeout);
  });
};

module.exports = {
  createInstitution,
  createIssuer,
  createParticipant,
  createRegulator,
  createSettelementBank,
};
