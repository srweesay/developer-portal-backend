const { Builder, By, Key, until } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");

async function initializeDriver() {
  const chromeOptions = new chrome.Options()
    .excludeSwitches("enable-automation")
    .addArguments("--headless"); // Run in headless mode
  return new Builder()
    .forBrowser("chrome")
    .setChromeOptions(chromeOptions)
    .build();
}

var username = "nbet15";
var pass = "m";

const args = process.argv.slice(2);

const org = {
  fullNameEnglish: args[0] || "Sample Bank Name",
  legacyCode: args[1] || "12345",
  type: args[2] || "Type A",
  establishedDate: args[3] || "2022-01-01",
  cashAccount: args[4] || "CA-12345",
  accountNO: args[5] || "987654321",
  swiftBic: args[6] || "NBETTAXXX",
  proprietaryId: args[7] || "",
};

async function login(driver, username, password) {
  try {
    await driver.get("https://172.19.1.23:9443/csd");
    await driver.manage().window().maximize();
    await driver.wait(until.elementLocated(By.id("details-button"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("proceed-link"))).click();
    await driver.sleep(1000);
    await driver
      .wait(until.elementLocated(By.name("j_username")))
      .sendKeys(username);
    await driver.wait(until.elementLocated(By.id("pass"))).sendKeys(password);
    await driver.wait(until.elementLocated(By.id("btnLogin"))).click();
  } catch (error) {
    console.error("Login failed:", error);
  }
}

async function settlementBankCreate(params) {
  const driver = await initializeDriver();
  try {
    await login(driver, username, pass);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//div[contains(text(),'Issuers')]"))
      .click();
    await driver.sleep(2000);
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.sleep(2000);
    await driver.switchTo().frame("ContentFrame");
    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > span > input"
        )
      )
      .sendKeys(`\b${params.fullNameEnglish}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-1 > li"))).click();
    await driver.sleep(2000);
    await driver
      .wait(until.elementLocated(By.id("legacyCode")))
      .sendKeys(params.legacyCode);
    await driver
      .wait(until.elementLocated(By.xpath("//a[@href='#Behavioral']")))
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            '//*[@id="entryForm"]/div[2]/div[2]/div[2]/div[1]/div/span/input'
          )
        )
      )
      .sendKeys(`\b${params.type}`);
    await driver
      .wait(until.elementLocated(By.css("#ui-id-3 > li:nth-child(2)")))
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            '//*[@id="entryForm"]/div[2]/div[2]/div[2]/div[2]/div/span/input'
          )
        )
      )
      .sendKeys(`\b${params.type}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-4 > li"))).click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            '//*[@id="entryForm"]/div[2]/div[2]/div[3]/div[2]/div[2]/div/div/label[2]/span'
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            '//*[@id="entryForm"]/div[2]/div[2]/div[4]/div[2]/div/div/div/label[2]/span'
          )
        )
      )
      .click();
    let toggle = await driver.wait(
      until.elementLocated(
        By.xpath('//*[@id="flag-equitiesIssuer"]/div/div/div/label[2]/span')
      )
    );
    await driver.executeScript("arguments[0].scrollIntoView(true);", toggle);
    await toggle.click();
    await driver
      .wait(until.elementLocated(By.id("incorpPlace")))
      .sendKeys("Addis Ababa");
    await driver
      .wait(until.elementLocated(By.id("incorpDateAsString")))
      .sendKeys(params.establishedDate);

    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(4) > div:nth-child(4) > div.form-field.IgnoreShowHide.incorpFields > div > div > label.toggle > span"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(2) > div:nth-child(4) > div:nth-child(4) > div.form-field.agentFields.incorpFields > div > span > input"
          )
        )
      )
      .sendKeys(`\b${params.fullNameEnglish}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-6 > li"))).click();
    await driver
      .wait(until.elementLocated(By.id("maxOwnAsString")))
      .sendKeys(60);

    await driver
      .wait(until.elementLocated(By.xpath('//*[@id="SettlementId"]/a')))
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(3) > c-widget > div > div.widget-box-header > div.widget-button-container > div > button"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css("#cashAccount > input.select-box.select-field")
        )
      )
      .sendKeys(`\b${params.cashAccount}`);
    await driver
      .wait(until.elementLocated(By.css("#cashAccount > div")))
      .click();
    await driver
      .wait(until.elementLocated(By.id("accountNumber")))
      .sendKeys(`\b${params.accountNO}`);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(3) > c-widget > div > div.modal-backdrop > div > div > div.row > div:nth-child(6) > div > div > div > label > span"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "#entryForm > div.form-content > div:nth-child(3) > c-widget > div > div.modal-backdrop > div > div > div.modal-buttons > button.button-primary"
          )
        )
      )
      .click();
    await driver.wait(until.elementLocated(By.id("btnValidate"))).click();
    await driver.sleep(2000);
    await driver
      .wait(until.elementLocated(By.className("icon-circle-check")))
      .click();
    await driver.sleep(2000);
    await approveIssuer(driver, params);
  } catch (error) {
    console.log(error);
  } finally {
    await driver.quit();
  }
}

async function approveIssuer(driver, params) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");
    await driver
      .wait(until.elementLocated(By.id("swiftId")))
      .sendKeys(params.swiftBic + params.proprietaryId);
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.css("#ui-id-1"))).click();
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.sleep(3000);
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving settelment bank:", error);
  }
}

settlementBankCreate(org);
