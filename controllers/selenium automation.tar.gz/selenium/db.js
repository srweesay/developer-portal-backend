const { Client } = require("pg");

const client = new Client({
  user: "csd",
  host: "localhost",
  database: "csd",
  password: "123",
  port: 7999,
});

async function getSchema() {
  try {
    await client.connect();

    const res = await client.query(`
      SELECT table_schema, table_name, column_name, data_type 
      FROM information_schema.columns 
      WHERE table_schema NOT IN ('information_schema', 'pg_catalog')
      ORDER BY table_schema, table_name, ordinal_position;
    `);

    console.log("Schema Information:");
    res.rows.forEach((row) => {
      console.log(
        `Schema: ${row.table_schema}, Table: ${row.table_name}, Column: ${row.column_name}, Type: ${row.data_type}`
      );
    });
  } catch (err) {
    console.error("Error fetching schema:", err.stack);
  } finally {
    await client.end();
  }
}

getSchema();
