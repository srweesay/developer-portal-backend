const { Builder, By, Key, until } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");

async function initializeDriver() {
  const chromeOptions = new chrome.Options()
    .excludeSwitches("enable-automation")
    .addArguments("--headless"); // Run in headless mode
  return new Builder()
    .forBrowser("chrome")
    .setChromeOptions(chromeOptions)
    .build();
}
var username = "nbet15";
var pass = "m";

const args = process.argv.slice(2);

const org = {
  fullNameEnglish: args[0],
  legacyCode: args[1],
  type: args[2],
  swiftBic: args[3],
  proprietaryId: args[4],
};

var username = "nbet15";
var pass = "m";

async function login(driver, username, password) {
  try {
    await driver.get("https://172.19.1.23:9443/csd");
    await driver.manage().window().maximize();
    await driver.wait(until.elementLocated(By.id("details-button"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("proceed-link"))).click();
    await driver.sleep(1000);
    await driver
      .wait(until.elementLocated(By.name("j_username")))
      .sendKeys(username);
    await driver.wait(until.elementLocated(By.id("pass"))).sendKeys(password);
    await driver.wait(until.elementLocated(By.id("btnLogin"))).click();
  } catch (error) {
    console.error("Login failed:", error);
  }
}

async function settlementBankCreate(params) {
  const driver = await initializeDriver();
  try {
    await login(driver, username, pass);
    await driver
      .wait(
        until.elementLocated(
          By.css(
            "body > div > core-menu > div > div.menu-container > div.menu-items-container > div:nth-child(4) > div > div > div.menu-item-label"
          )
        )
      )
      .click();
    await driver
      .findElement(By.xpath("//div[contains(text(),'Settlement banks')]"))
      .click();
    await driver.sleep(2000);
    await driver
      .findElement(By.xpath("//a[normalize-space()='Create']"))
      .click();
    await driver.sleep(2000);

    await driver.switchTo().frame("ContentFrame");
    await driver
      .findElement(
        By.css(
          "#entryForm > div.form-content > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > span > input"
        )
      )
      .sendKeys(`\b${params.fullNameEnglish}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-1 > li"))).click();
    await driver.sleep(2000);
    await driver
      .wait(until.elementLocated(By.id("legacyCode")))
      .sendKeys(params.legacyCode);
    await driver
      .wait(until.elementLocated(By.xpath("//a[@href='#Behavioral']")))
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            "//span[@class='ComboBoxWidget Options3 Wrapper']//input[@title='-']"
          )
        )
      )
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath("//li[normalize-space()='Commercial Bank']")
        )
      )
      .click();

    await driver
      .findElement(
        By.css(
          "#tabs-configuration > div.row > div:nth-child(2) > div > span > input"
        )
      )
      .sendKeys(`\b${params.type}`);
    await driver.wait(until.elementLocated(By.css("#ui-id-3 > li"))).click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            '//*[@id="tabs-configuration"]/div[2]/div[4]/div/div/label[2]/span'
          )
        )
      )
      .click();
    await driver
      .wait(until.elementLocated(By.xpath("//a[@href='#Settlement']")))
      .click();
    await driver
      .wait(
        until.elementLocated(
          By.xpath(
            "//c-widget[@name='cashSettlementSystems']//button[@class='button-secondary'][normalize-space()='Add record']"
          )
        )
      )
      .click();
    await driver
      .wait(until.elementLocated(By.id("bankCode")))
      .sendKeys(params.swiftBic);
    await driver
      .wait(until.elementLocated(By.className("button-primary")))
      .click();
    await driver.findElement(By.id("btnValidate")).click();
    await driver.sleep(2000);
    await driver.findElement(By.className("icon-circle-check")).click();
    await driver.sleep(2000);
    await approveSettelmentBank(driver, params);
  } catch (err) {
    console.log(err);
  } finally {
    await driver.quit();
  }
}
async function approveSettelmentBank(driver, params) {
  try {
    await driver.switchTo().defaultContent();
    await driver
      .wait(until.elementLocated(By.xpath("//a[normalize-space()='Approve']")))
      .click();
    await driver.switchTo().frame("ContentFrame");
    await driver
      .wait(until.elementLocated(By.id("swiftId")))
      .sendKeys(params.swiftBic + params.proprietaryId);
    console.log(params.swiftBic);
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("btnOk"))).click();
    await driver.sleep(3000);
    await driver.wait(until.elementLocated(By.css("#\\31"))).click();
    await driver.wait(until.elementLocated(By.id("btnApprove"))).click();
  } catch (error) {
    console.error("Error approving settelment bank:", error);
  }
}
settlementBankCreate(org);
