const { Builder, By, Key, until } = require("selenium-webdriver");
const { actions } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");

const CSD_Link = "https://172.19.1.23:9443/csd";
const duration = 5000;

async function initializeDriver() {
  let chromeOptions = new chrome.Options();
  chromeOptions.excludeSwitches("enable-automation");

  let driver = new Builder()
    .forBrowser("chrome")
    .setChromeOptions(chromeOptions)
    .build();

  return driver;
}

async function setupBrowser(driver) {
  await driver.get(CSD_Link);
  await driver.manage().window().maximize();
  await handleSecurityWarning(driver);
}

async function handleSecurityWarning(driver) {
  try {
    await driver.wait(until.elementLocated(By.id("details-button"))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.id("proceed-link"))).click();
    await driver.sleep(1000);
  } catch (error) {
    console.log("Security warning not present or couldn't be handled:", error);
  }
}

async function login(driver, username, password) {
  await driver
    .wait(until.elementLocated(By.name("j_username")))
    .sendKeys(username);
  await driver.sleep(1000);
  await driver.wait(until.elementLocated(By.id("pass"))).sendKeys(password);
  await driver.sleep(1000);
  await driver.wait(until.elementLocated(By.id("btnLogin"))).click();
}

// Export all functions
module.exports = {
  initializeDriver,
  setupBrowser,
  handleSecurityWarning,
  login,
  duration,
};
